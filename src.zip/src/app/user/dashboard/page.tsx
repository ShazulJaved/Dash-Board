'use client';

import { useEffect, useState, useRef } from 'react';
import { auth, db } from '@/lib/firebase/firebase';
import { useAuthState } from 'react-firebase-hooks/auth';
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar, Clock, UserCheck, StickyNote } from "lucide-react";
import Link from "next/link";
import { useToast } from "@/components/ui/use-toast";
import { Skeleton } from "@/components/ui/skeleton";
import { doc, getDoc, collection, query, where, getDocs, Timestamp } from 'firebase/firestore';
import { fetchUserAttendanceStats } from '@/lib/attendance-utils';


interface UserStats {
  attendance: number;
  leaveBalance: number;
  status: 'Checked In' | 'Checked Out' | 'Not Checked In';
}

// Custom hook for count animation
const useCountAnimation = (
  targetValue: number, 
  duration: number = 2000,
  format: 'percentage' | 'number' | 'days' | 'time' = 'number'
) => {
  const [currentValue, setCurrentValue] = useState(0);

  useEffect(() => {
    if (targetValue === 0) {
      setCurrentValue(0);
      return;
    }

    let startTime: number;
    const startValue = 0;
    const endValue = targetValue;

    const animate = (timestamp: number) => {
      if (!startTime) startTime = timestamp;
      const progress = timestamp - startTime;
      const percentage = Math.min(progress / duration, 1);

      // Easing function for smooth animation
      const easeOutQuart = 1 - Math.pow(1 - percentage, 4);
      const current = startValue + (endValue - startValue) * easeOutQuart;

      setCurrentValue(Math.floor(current));

      if (percentage < 1) {
        requestAnimationFrame(animate);
      } else {
        setCurrentValue(endValue);
      }
    };

    requestAnimationFrame(animate);
  }, [targetValue, duration]);

  // Format the output based on the type
  const formatValue = () => {
    switch (format) {
      case 'percentage':
        return `${currentValue}%`;
      case 'days':
        return `${currentValue} Days`;
      case 'time':
        return `${currentValue.toString().padStart(2, '0')}:00`;
      default:
        return currentValue.toString();
    }
  };

  return {
    rawValue: currentValue,
    displayValue: formatValue()
  };
};

export default function UserDashboard() {
  const [user] = useAuthState(auth);
  const { toast } = useToast();
  const [currentTime, setCurrentTime] = useState(new Date());
  const [greeting, setGreeting] = useState('');
  const [userData, setUserData] = useState<any>(null);
  const [notes, setNotes] = useState<{ id: string; text: string; completed: boolean }[]>([]);
   // Status background image theming
  const getStatusBackground = (): string => {
    switch (userStats.status) {
      case 'Checked In':
        return "url('/assets/checked-in-bg.jpg')";
      case 'Checked Out':
        return "url('/assets/checked-out-bg.jpg')";
      default:
        return "url('/assets/not-checked-bg.jpg')";
    }
  };

  // Stats state
  const [userStats, setUserStats] = useState<UserStats>({
    attendance: 0,
    leaveBalance: 0,
    status: 'Not Checked In'
  });

  const [loading, setLoading] = useState(true);

  // Set up clock and greeting
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);

    const hour = new Date().getHours();
    if (hour < 12) setGreeting('Good Morning');
    else if (hour < 18) setGreeting('Good Afternoon');
    else setGreeting('Good Evening');

    return () => clearInterval(timer);
  }, []);

  // Fetch user data and attendance status
  useEffect(() => {
    if (!user) return;

    const fetchUserData = async () => {
      try {
        setLoading(true);
        
        // Get user profile data
        const userDocRef = doc(db, 'users', user.uid);
        const userDocSnap = await getDoc(userDocRef);

        let userAttendance = 0;
        let userLeaveBalance = 0;

        if (userDocSnap.exists()) {
          const data = userDocSnap.data();
          setUserData(data);
          
          // Get attendance and leave balance from user document
          userAttendance = data.attendance || 0;
          userLeaveBalance = data.leaveBalance || 0;
        }

        // Fetch attendance stats from attendance collection
        try {
          const attendanceStats = await fetchUserAttendanceStats(user.uid);
          // Use the attendance percentage from attendance collection, fallback to user document
          userAttendance = attendanceStats.monthlyAttendance || userAttendance;
        } catch (error) {
          console.error('Error fetching attendance stats:', error);
          // Continue with user document data if attendance collection fails
        }

        // Update stats with the fetched data
        setUserStats(prev => ({
          ...prev,
          attendance: userAttendance,
          leaveBalance: userLeaveBalance
        }));

        // Get today's date at midnight and next day for accurate query
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        const tomorrow = new Date(today);
        tomorrow.setDate(today.getDate() + 1);

        // Query for today's attendance record
        const attendanceQuery = query(
          collection(db, 'attendance'),
          where('userId', '==', user.uid),
          where('date', '>=', Timestamp.fromDate(today)),
          where('date', '<', Timestamp.fromDate(tomorrow))
        );

        const attendanceSnapshot = await getDocs(attendanceQuery);

        if (!attendanceSnapshot.empty) {
          // User has an attendance record for today
          const attendanceData = attendanceSnapshot.docs[0].data();

          if (attendanceData.checkOut) {
            setUserStats(prev => ({ ...prev, status: 'Checked Out' }));
          } else if (attendanceData.checkIn) {
            setUserStats(prev => ({ ...prev, status: 'Checked In' }));
          } else {
            setUserStats(prev => ({ ...prev, status: 'Not Checked In' }));
          }
        } else {
          setUserStats(prev => ({ ...prev, status: 'Not Checked In' }));
        }
      } catch (error) {
        console.error('Error fetching data:', error);
        toast({
          variant: "destructive",
          title: "Error",
          description: "Failed to load user data"
        });
      } finally {
        setLoading(false);
      }
    };

    fetchUserData();

    // Set up polling for status updates
    const statusInterval = setInterval(() => {
      fetchUserData();
    }, 30000);

    return () => clearInterval(statusInterval);
  }, [user, toast]);

  // Status color theming
  const getStatusColor = (): string => {
    switch (userStats.status) {
      case 'Checked In':
        return 'from-green-100 to-green-50 border-green-400';
      case 'Checked Out':
        return 'from-blue-100 to-blue-50 border-blue-400';
      default:
        return 'from-red-100 to-red-50 border-red-400';
    }
  };

  // Status text color
  const getStatusTextColor = (): string => {
    switch (userStats.status) {
      case 'Checked In':
        return 'text-green-700';
      case 'Checked Out':
        return 'text-blue-700';
      default:
        return 'text-red-700';
    }
  };

  // Manual refresh function
  const refreshStatus = async () => {
    if (!user) return;
    try {
      // Refresh all data
      const userDocRef = doc(db, 'users', user.uid);
      const userDocSnap = await getDoc(userDocRef);

      if (userDocSnap.exists()) {
        const data = userDocSnap.data();
        const attendanceStats = await fetchUserAttendanceStats(user.uid);
        
        setUserStats(prev => ({
          ...prev,
          attendance: attendanceStats.monthlyAttendance || data.attendance || 0,
          leaveBalance: data.leaveBalance || 0
        }));
      }

      const today = new Date();
      today.setHours(0, 0, 0, 0);
      const tomorrow = new Date(today);
      tomorrow.setDate(today.getDate() + 1);

      const attendanceQuery = query(
        collection(db, 'attendance'),
        where('userId', '==', user.uid),
        where('date', '>=', Timestamp.fromDate(today)),
        where('date', '<', Timestamp.fromDate(tomorrow))
      );
      const attendanceSnapshot = await getDocs(attendanceQuery);

      if (!attendanceSnapshot.empty) {
        const attendanceData = attendanceSnapshot.docs[0].data();
        if (attendanceData.checkOut) {
          setUserStats(prev => ({ ...prev, status: 'Checked Out' }));
        } else if (attendanceData.checkIn) {
          setUserStats(prev => ({ ...prev, status: 'Checked In' }));
        } else {
          setUserStats(prev => ({ ...prev, status: 'Not Checked In' }));
        }
      } else {
        setUserStats(prev => ({ ...prev, status: 'Not Checked In' }));
      }
      
      toast({
        title: "Status Updated",
        description: "All data refreshed successfully",
      });
    } catch (error) {
      console.error('Error refreshing status:', error);
      toast({
        variant: "destructive",
        title: "Error",
        description: "Failed to refresh data"
      });
    }
  };

  if (!user || !userData || loading) {
    return (
      <div className="p-8 relative min-h-screen bg-gradient-to-b from-gray-50 to-white">
        
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          {[...Array(4)].map((_, i) => (
            <Skeleton key={i} className="h-24 w-full" />
          ))}
        </div>
        <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {[...Array(3)].map((_, i) => (
            <Skeleton key={i} className="h-40 w-full" />
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen  p-8 relative">

      {/* Welcome Header */}
      <div className="text-center space-y-4 mb-12 z-10 relative">
        <h1 className="text-4xl font-bold text-black bg-clip-text ">
          {greeting}, {userData?.displayName || user?.email?.split('@')[0] || 'User'} 👋
        </h1>
        <p className="text-gray-600 text-lg">
          {currentTime.toLocaleDateString([], {
            weekday: 'long', year: 'numeric', month: 'long', day: 'numeric'
          })}
        </p>
      </div>

      {/* Animated Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12 z-10 relative">
        <AnimatedCard
          color="from-blue-100 to-blue-50 border-blue-400"
          icon={<Clock className="w-7 h-7 text-blue-500" />}
          label="Time"
          value={currentTime.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
        />
        <AnimatedCard
          color={getStatusColor()}
          icon={null}
          label="Status"
          value={userStats.status}
          textColor={getStatusTextColor()}
          onClick={refreshStatus}
          isStatus
        />
        {/* Attendance Card with Counting Animation */}
        <AnimatedCard
          color="from-purple-100 to-purple-50 border-purple-400"
          icon={null}
          label="Attendance"
          number={userStats.attendance}
          format="percentage"
          duration={1500} value={''} />
        {/* Leave Balance Card with Counting Animation */}
        <AnimatedCard
          color="from-orange-100 to-orange-50 border-orange-400"
          icon={null}
          label="Leave Balance"
          number={userStats.leaveBalance}
          format="days"
          duration={1200} value={''}        />
        <AnimatedCard
          color="from-yellow-100 to-yellow-50 border-yellow-400"
          icon={<StickyNote className="w-7 h-7 text-yellow-500" />}
          label="Notes"
          value={notes.length > 0 ? notes[notes.length - 1].text.slice(0, 30) + "..." : "No notes yet"}
          number={notes.length}
        />
        
          
      </div>
      
      {/* Quick Actions Grid */}
      <h2 className="text-2xl font-semibold text-gray-800 mb-6 z-10 relative">Quick Actions</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 max-w-6xl mx-auto z-10 relative">
        <Link href="/user/attendance">
          <ActionCard
            color="border-l-blue-500"
            icon={<Clock className="h-5 w-5 text-blue-500" />}
            title="Attendance"
            desc="Track your daily attendance"
            action="Check In/Out →"
            actionColor="text-blue-500"
          />
        </Link>
        <Link href="/user/leave-requests">
          <ActionCard
            color="border-l-green-500"
            icon={<Calendar className="h-5 w-5 text-green-500" />}
            title="Leave Requests"
            desc="Manage your leaves"
            action="Request Leave →"
            actionColor="text-green-500"
          />
        </Link>
        <Link href="/user/profile">
          <ActionCard
            color="border-l-purple-500"
            icon={<UserCheck className="h-5 w-5 text-purple-500" />}
            title="Your Profile"
            desc="Update your information"
            action="View Profile →"
            actionColor="text-purple-500"
          />
        </Link>
        <Link href="/user/NotesPage">
          <ActionCard
            color="border-l-yellow-500"
            icon={<StickyNote className="h-5 w-5 text-yellow-500" />}
            title="Notes"
            desc="Add, view, and manage your notes"
            action="Open Notes →"
            actionColor="text-yellow-500"
          />
        </Link>
      </div>
    </div>
  );
}

// Animated Stats Card with 3D Hover
function AnimatedCard({
  color,
  icon,
  label,
  value,
  textColor = "text-gray-800",
  onClick,
  isStatus = false,
  number,
  format = 'number',
  duration = 2000
}: {
  color: string,
  icon?: React.ReactNode,
  label: string,
  value: string | number,
  textColor?: string,
  onClick?: () => void,
  isStatus?: boolean,
  number?: number,
  format?: 'percentage' | 'number' | 'days' | 'time',
  duration?: number
}) {
  const { displayValue } = useCountAnimation(number || 0, duration, format);
  
  // 3D hover effect
  const cardRef = useRef<HTMLDivElement | null>(null);
  const handleMouseMove = (e: React.MouseEvent<HTMLDivElement>) => {
    const card = cardRef.current;
    if (!card) return;
    const { left, top, width, height } = card.getBoundingClientRect();
    const x = e.clientX - left - width / 2;
    const y = e.clientY - top - height / 2;
    card.style.transform = `perspective(800px) rotateY(${x / 20}deg) rotateX(${-y / 20}deg) scale(1.03)`;
  };
  
  const handleMouseLeave = () => {
    if (cardRef.current)
      cardRef.current.style.transform = '';
  };

  // If number prop is provided, use the animated value
  const finalDisplayValue = number !== undefined ? displayValue : value;

  return (
    <div
      ref={cardRef}
      className={`relative bg-gradient-to-br ${color} border shadow-xl rounded-xl px-6 py-8 transition-transform duration-300 will-change-transform hover:shadow-2xl cursor-pointer group`}
      style={{
        transition: 'transform 0.25s cubic-bezier(.25,.8,.25,1), box-shadow 0.2s'
      }}
      onMouseMove={handleMouseMove}
      onMouseLeave={handleMouseLeave}
      onClick={onClick}
      tabIndex={isStatus ? 0 : undefined}
      role={isStatus ? "button" : undefined}
      aria-label={isStatus ? "Refresh Status" : undefined}
      title={isStatus ? "Click to refresh status" : undefined}
    >
      {icon && <div className="mb-2">{icon}</div>}
      <div className="text-sm font-semibold text-gray-600">{label}</div>
      <div className={`text-3xl font-bold mt-1 ${textColor}`}>
        {finalDisplayValue}
      </div>
      {/* Animated bar for number stats */}
      {typeof number === 'number' && (
        <div className="w-full h-2 bg-gray-200 rounded-full mt-4 overflow-hidden">
          <div
            className="h-full rounded-full transition-all duration-1000"
            style={{
              width: `${number}%`,
              background: 'linear-gradient(90deg, #6366f1 0%, #f472b6 100%)'
            }}
          />
        </div>
      )}
      {/* Shine effect */}
      <div className="absolute inset-0 pointer-events-none rounded-xl overflow-hidden">
        <div className="absolute -top-6 -left-16 w-48 h-12 bg-white bg-opacity-20 rotate-12 blur-xl animate-shine" />
      </div>
    </div>
  );
}

// Quick Action Card
function ActionCard({
  color,
  icon,
  title,
  desc,
  action,
  actionColor
}: {
  color: string,
  icon: React.ReactNode,
  title: string,
  desc: string,
  action: string,
  actionColor: string
}) {
  return (
    <Card className={`hover:shadow-lg hover:-translate-y-1 transition-all cursor-pointer border-l-4 ${color} bg-white/80`}>
      <CardHeader className="flex flex-row items-center justify-between pb-2">
        <CardTitle className="text-lg font-medium">{title}</CardTitle>
        {icon}
      </CardHeader>
      <CardContent>
        <p className="text-gray-600">{desc}</p>
        <p className={`text-sm mt-2 font-medium ${actionColor}`}>
          {action}
        </p>
      </CardContent>
    </Card>
  );
}

// Floating Particles Background
// Enhanced Animated Background
